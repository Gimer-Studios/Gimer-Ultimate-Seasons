package gimer.gimerultimateseasons;


public enum Season {
    SPRING,
    SUMMER,
    AUTUMN,
    WINTER
}